package tw.com.newtaipei.earthquake;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String CHANNEL_ID = "earthquake_alerts";
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8,13,24));
        getWindow().setNavigationBarColor(Color.rgb(8,13,24));
        createChannel();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(20));
        root.setBackgroundColor(Color.rgb(8,13,24));

        TextView title = text("新北地震速報", 28, Color.WHITE, true);
        root.addView(title);

        TextView sub = text("NEW TAIPEI EARTHQUAKE ALERT", 12, Color.LTGRAY, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(4); root.addView(sub, sp);

        TextView status = text("● 尚未連線官方地震資料", 16, Color.rgb(255,190,80), true);
        LinearLayout.LayoutParams st = new LinearLayout.LayoutParams(-1, -2);
        st.topMargin = dp(28); root.addView(status, st);

        TextView card = text("目前沒有載入即時地震資料\n\n完成官方資料授權設定後，才會顯示最新地震報告及新北各區震度。", 17, Color.WHITE, false);
        card.setPadding(dp(16), dp(20), dp(16), dp(20));
        card.setBackgroundColor(Color.rgb(22,31,48));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(16); root.addView(card, cp);

        TextView note = text("測試通知不代表真實地震警報。請勿將本測試版當作唯一防災依據。", 13, Color.LTGRAY, false);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = dp(18); root.addView(note, np);

        Button test = new Button(this);
        test.setText("發送測試通知");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(24); root.addView(test, bp);
        test.setOnClickListener(v -> sendTestNotification());

        TextView footer = text("版本 1.0.0｜測試建置版", 12, Color.GRAY, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(30); root.addView(footer, fp);

        setContentView(root);
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "地震速報通知", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("新北地震速報測試通知");
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
    }

    private void sendTestNotification() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
            Toast.makeText(this, "請允許通知權限後再按一次", Toast.LENGTH_LONG).show();
            return;
        }
        NotificationManager nm = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new android.app.Notification.Builder(this, CHANNEL_ID)
            : new android.app.Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert)
         .setContentTitle("新北地震速報｜測試")
         .setContentText("這是測試通知，不是真實地震警報。")
         .setStyle(new android.app.Notification.BigTextStyle().bigText("新北地震速報通知測試成功。這不是實際地震資訊。"))
         .setAutoCancel(true);
        nm.notify(1001, b.build());
        Toast.makeText(this, "已送出測試通知", Toast.LENGTH_SHORT).show();
    }
}
